def root(base, indice):
    return float(base ** (1 / indice))
