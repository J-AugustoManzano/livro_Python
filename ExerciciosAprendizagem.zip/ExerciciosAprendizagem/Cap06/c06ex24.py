﻿from math import pow, sqrt

print(pow(2, 3))
print(sqrt(25))

enter = input("\nPressione <Enter> para encerrar... ")
