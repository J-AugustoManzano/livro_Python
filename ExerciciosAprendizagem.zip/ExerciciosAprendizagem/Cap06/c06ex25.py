﻿from math import pow as potencia, sqrt as raiz

print(potencia(2, 3))
print(raiz(25))

enter = input("\nPressione <Enter> para encerrar... ")
