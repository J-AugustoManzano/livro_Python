﻿from math import pow

print(pow(2, 3))

enter = input("\nPressione <Enter> para encerrar... ")
