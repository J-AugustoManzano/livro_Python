﻿class Dobro(object):

    def __init__(self, valor):
        self.resultado = valor * 2

calculo = Dobro(7)

print("Resultado ", calculo)

enter = input("\nPressione <Enter> para encerrar... ")
