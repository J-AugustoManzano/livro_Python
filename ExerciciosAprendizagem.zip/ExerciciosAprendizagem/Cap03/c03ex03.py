﻿numero = int(input("Entre um valor numérico inteiro: "))

if (numero >= 20 and numero <= 90):
    print("O valor está entre 20 e 90.")
else:
    print("O valor não está entre 20 e 90.")

enter = input("\nPressione <Enter> para encerrar... ")
