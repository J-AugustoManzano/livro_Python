﻿valor = int(input("Entre um valor numérico inteiro: "))

print()

if not (valor >= 10):
    print("Valor informado = %d." % valor)
else:
    print("Valor inválido.")

enter = input("\nPressione <Enter> para encerrar... ")
