﻿a = int(input("Entre valor <A>: "))
b = int(input("Entre valor <B>: "))

r = a + b;

if (r >= 10):
    print("Resultado = %i" % (r + 5))
    print("A")
else:
    print("Resultado = %i" % (r - 7))
    print("B")
print("C")

enter = input("\nPressione <Enter> para encerrar... ")
