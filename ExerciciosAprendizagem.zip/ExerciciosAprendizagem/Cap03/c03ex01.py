﻿a = int(input("Entre valor <A>: "))
b = int(input("Entre valor <B>: "))

r = a + b;

if (r > 10):
    print("Resultado = %i" % r)

enter = input("\nPressione <Enter> para encerrar... ")
