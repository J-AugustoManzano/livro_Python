﻿for i in range(20, 0, -2):
    print("%2d" % i)

enter = input("\nPressione <Enter> para encerrar... ")
