﻿for i in range(1, 13, 2):
    print("%2d" % i)

enter = input("\nPressione <Enter> para encerrar... ")
