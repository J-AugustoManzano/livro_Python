﻿for i in range(1, 11):
    if (i == 6): continue
    print("%2d" % i)

enter = input("\nPressione <Enter> para encerrar... ")
