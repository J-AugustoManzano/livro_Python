﻿i = 1
while (i <= 10):
    if (i == 6): break
    print("%2d" % i)
    i = i + 1

enter = input("\nPressione <Enter> para encerrar... ")
