﻿i = 1
while (True):
    print("%2d" % i)
    i = i + 1
    if (i > 10): break

enter = input("\nPressione <Enter> para encerrar... ")
