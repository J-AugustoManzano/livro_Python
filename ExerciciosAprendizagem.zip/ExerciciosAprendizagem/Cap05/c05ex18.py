﻿def pausa():
    enter = input("\nPressione <Enter> para encerrar... ")

identidade = lambda x: x

print("A função identidade de %d é %d." % (5, identidade(5)))

pausa()
