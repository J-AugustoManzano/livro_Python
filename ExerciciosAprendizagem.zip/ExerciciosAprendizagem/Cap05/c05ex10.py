﻿def pausa():
    enter = input("\nPressione <Enter> para encerrar... ")

def linha(caractere = "-"):
    print(caractere * 80)

linha()
linha('=')
linha('+')
linha('x')

pausa()
