﻿def pausa():
    enter = input("\nPressione <Enter> para encerrar... ")

def centraTexto(texto):
    print(texto.center(80))

centraTexto("Estudo de linguagem Python 2018")

pausa()
