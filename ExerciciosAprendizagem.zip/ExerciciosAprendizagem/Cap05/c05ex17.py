﻿def pausa():
    enter = input("\nPressione <Enter> para encerrar... ")

raiz = lambda base, indice: base ** (1 / indice)

print("Raiz da base  5 com índice  6 = %20.10f" % raiz(5, 2))
print("Raiz da base  2 com índice  2 = %20.10f" % raiz(2, 2))

pausa()
