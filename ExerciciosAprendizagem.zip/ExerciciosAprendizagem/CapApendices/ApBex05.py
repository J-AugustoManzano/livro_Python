﻿import turtle

def triangulo():
    for x in range(3):
        turtle.fd(100)
        turtle.rt(120)

triangulo()
