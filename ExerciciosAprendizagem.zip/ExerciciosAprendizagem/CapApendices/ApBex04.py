﻿from turtle import *

def quadrado():
    for x in range(4):
        fd(100)
        rt(90)

quadrado()
