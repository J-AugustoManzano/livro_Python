﻿import constman

print(constman.M_E)
print(constman.M_LOG2E)
print(constman.M_LOG10E)
print(constman.M_LN2)
print(constman.M_LN10)
print(constman.M_PI)
print(constman.M_PI_2)
print(constman.M_PI_4)
print(constman.M_1_PI)
print(constman.M_2_PI)
print(constman.M_2_SQRTPI)
print(constman.M_SQRT2)
print(constman.M_SQRT1_2)

enter = input("\nPressione <Enter> para encerrar... ")
