﻿import const

const.pi = 3.14159

print(const.pi)

enter = input("\nPressione <Enter> para encerrar... ")
