﻿import turtle

def circulo():
    for x in range(360):
        turtle.fd(1.5)
        turtle.rt(1)

circulo()
