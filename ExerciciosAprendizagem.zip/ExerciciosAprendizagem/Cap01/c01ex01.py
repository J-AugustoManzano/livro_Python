﻿print("Alô, mundo!")
