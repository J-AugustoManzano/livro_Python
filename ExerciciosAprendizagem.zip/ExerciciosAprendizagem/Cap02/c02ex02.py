nome = input("Informe seu nome: ")
print("Olá, %s" % nome)
enter = input("\nPressione <Enter> para encerrar... ")
