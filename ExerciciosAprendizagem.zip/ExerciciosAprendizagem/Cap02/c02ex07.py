﻿x = True
y = False

print("Valor logico verdadeiro de X ...: %s" % x);
print("Valor logico falso de Y ........: %s" % y);

enter = input("\nPressione <Enter> para encerrar... ")
