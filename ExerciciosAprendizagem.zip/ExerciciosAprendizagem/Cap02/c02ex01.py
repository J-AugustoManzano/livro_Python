print("Programação na linguagem Python.")
enter = input("\nPressione <Enter> para encerrar... ")
