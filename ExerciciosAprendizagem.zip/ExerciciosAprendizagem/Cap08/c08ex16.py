﻿valores = [1, 2, 3, 4, 5]
soma = 0

for i in valores:
    soma += i

print("Somatório = ", soma)

enter = input("\nPressione <Enter> para encerrar... ")
