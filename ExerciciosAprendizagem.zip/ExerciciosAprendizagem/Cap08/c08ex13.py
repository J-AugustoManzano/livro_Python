﻿tupla = ("A", "B", "C", "D", "E")
for i, j in enumerate(tupla):
    print(i, " - ", j)

enter = input("\nPressione <Enter> para encerrar... ")
