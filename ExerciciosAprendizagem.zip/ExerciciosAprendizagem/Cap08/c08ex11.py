﻿for letra in "Estudo de Python":
    print(letra)

enter = input("\nPressione <Enter> para encerrar... ")
