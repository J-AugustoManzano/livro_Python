﻿lista = [1, 2, 3, 4, 5]
for indice in (lista):
    print(indice - 1, " - ", lista[indice - 1])

enter = input("\nPressione <Enter> para encerrar... ")
