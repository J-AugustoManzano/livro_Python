﻿def mostraItem(a, b, c, d, e):
    print(a)
    print(b)
    print(c)
    print(d)
    print(e)

valores = [0, 2, 4, 5, 8]

mostraItem(*valores)

enter = input("\nPressione <Enter> para encerrar... ")
