arquivo = open("ARQBIN02.BIN", "rb")

arquivo.close()    

enter = input("\nPressione <Enter> para encerrar... ")
