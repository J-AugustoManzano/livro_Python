arquivo = open("ARQTXT01.TEX", "w")
print("Arquivo 'ARQTXT01.TEX' foi criado ou recriado.")
arquivo.close()

enter = input("\nPressione <Enter> para encerrar... ")
