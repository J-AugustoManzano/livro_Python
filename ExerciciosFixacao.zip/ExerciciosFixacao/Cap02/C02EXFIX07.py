import math

r = float(input("Informe valor do raio de uma circunferência: "))

vol = math.pi * r**2

print()
print("Área = %6.2f" % vol)

enter = input("\nPressione <Enter> para encerrar... ")
