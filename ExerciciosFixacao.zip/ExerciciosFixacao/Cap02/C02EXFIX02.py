f = float(input("Informe uma temperatura em graus Fahrenheit: "))

c = ((f - 32.0) * 5.0) / 9.0

print()
print("Celsius = %f" % c)

enter = input("\nPressione <Enter> para encerrar... ")
