c = eval(input("Informe uma temperatura em graus Celsius : "))

f = (9.0 * c + 160.0) / 5.0

print()
print("Fahrenheit = %f" % f)

enter = input("\nPressione <Enter> para encerrar... ")
