a = int(input("Informe valor <A>: "))
b = int(input("Informe valor <B>: "))
c = int(input("Informe valor <C>: "))

r = a**2 + b**2 + c**2 

print()
print("Resultado = %i" % r)

enter = input("\nPressione <Enter> para encerrar... ")
