a = float(input("Informe valor <A>: "))
b = float(input("Informe valor <B>: "))

r1 = a + b
r2 = a - b
r3 = a * b
r4 = a / b

print()
print("Adição .........: %f" % r1)
print("Subtração ......: %f" % r2)
print("Multiplicação ..: %f" % r3)
print("Divisão ........: %f" % r4)

enter = input("\nPressione <Enter> para encerrar... ")
