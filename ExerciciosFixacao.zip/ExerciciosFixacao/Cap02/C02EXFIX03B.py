a = int(input("Informe valor <A>: "))
b = int(input("Informe valor <B>: "))

a, b = b, a

print()
print("<A> = %i" % a)
print("<B> = %i" % b)

enter = input("\nPressione <Enter> para encerrar... ")
