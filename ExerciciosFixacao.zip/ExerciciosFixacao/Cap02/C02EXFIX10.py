n = int(input("Informe um valor numérico inteiro: "))

print()
print("Sucessor .....: %i" % (n+1))
print("Antecessor ...: %i" % (n-1))

enter = input("\nPressione <Enter> para encerrar... ")
