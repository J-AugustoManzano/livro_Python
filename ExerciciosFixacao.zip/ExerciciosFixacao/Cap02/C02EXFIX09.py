b = int(input("Informe valor da base .......: "))
e = int(input("Informe valor do expoente ...: "))

r = b ** e

print()
print("Potência = %i" % r)

enter = input("\nPressione <Enter> para encerrar... ")
