a = int(input("Informe valor <A>: "))
b = int(input("Informe valor <B>: "))

x = a
a = b
b = x

print()
print("<A> = %i" % a)
print("<B> = %i" % b)

enter = input("\nPressione <Enter> para encerrar... ")
