a = int(input("Informe valor <A>: "))
b = int(input("Informe valor <B>: "))

r = (a - b) ** 2

print()
print("Resultado = %i" % r)

enter = input("\nPressione <Enter> para encerrar... ")
