a = []
b = []

for i in range(8):
    a.append(int(input("Entre o {0:2}o. valor em <A>: ".format(i + 1))))

for i in range(8):
    b.append(a[i] ** 2)

print()
for i in range(8):
    print("A[{0:2}] = {1:4} | B[{0:2}] = {2:4}".format(i + 1, a[i], b[i]))

enter = input("\nPressione <Enter> para encerrar... ")
