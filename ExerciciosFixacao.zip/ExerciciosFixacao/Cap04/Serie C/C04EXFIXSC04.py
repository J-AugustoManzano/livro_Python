for i in range(0, 21):
    if (i % 2 != 0):
        print("%3d" % i)

enter = input("\nPressione <Enter> para encerrar... ")
