for i in range(1, 200):
    if (i % 4 == 0):
        print("%3d" % i)

enter = input("\nPressione <Enter> para encerrar... ")
