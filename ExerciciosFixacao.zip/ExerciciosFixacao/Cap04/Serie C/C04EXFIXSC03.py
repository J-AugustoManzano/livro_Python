s = 0
for i in range(1, 501):
    if (i % 2 == 0):
        s += i

print("%d" % s)

enter = input("\nPressione <Enter> para encerrar... ")
