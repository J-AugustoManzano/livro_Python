s = 0
for i in range(1, 101):
    s += i

print("%d" % s)

enter = input("\nPressione <Enter> para encerrar... ")
