for i in range(15, 201):
    print("%5d" % i**2)

enter = input("\nPressione <Enter> para encerrar... ")
