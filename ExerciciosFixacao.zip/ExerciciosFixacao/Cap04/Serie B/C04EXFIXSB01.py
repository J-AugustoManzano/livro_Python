i = 15
while not (i > 200):
    print("%5d" % i**2)
    i = i + 1

enter = input("\nPressione <Enter> para encerrar... ")
