s = 0
i = 1
while not (i > 500):
    if (i % 2 == 0):
        s += i
    i += 1

print("%d" % s)

enter = input("\nPressione <Enter> para encerrar... ")
