i = 0
while not (i > 20):
    if (i % 2 != 0):
        print("%3d" % i)
    i += 1

enter = input("\nPressione <Enter> para encerrar... ")
