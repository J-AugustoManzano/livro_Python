i = 1
while (i <= 199):
    if (i % 4 == 0):
        print("%3d" % i)
    i += 1

enter = input("\nPressione <Enter> para encerrar... ")
