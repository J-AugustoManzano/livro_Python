s = 0
i = 1
while (i <= 100):
    s += i
    i += 1

print("%d" % s)

enter = input("\nPressione <Enter> para encerrar... ")
