a = int(input("Informe valor <A>: "))
b = int(input("Informe valor <B>: "))

if (a > b):
    r = a - b
else:
    r = b - a

print()
print("Resultado = %i" % r)

enter = input("\nPressione <Enter> para encerrar... ")
