n = int(input("Informe um valor numérico inteiro: "))

if not (n > 3):
    print()
    print("Valor = %i" % n)

enter = input("\nPressione <Enter> para encerrar... ")
